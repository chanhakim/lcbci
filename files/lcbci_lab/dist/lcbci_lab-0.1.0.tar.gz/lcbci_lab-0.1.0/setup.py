# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lcbci_lab']

package_data = \
{'': ['*']}

install_requires = \
['pyqt5>=5.15.0,<6.0.0', 'pyqtgraph>=0.11.0,<0.12.0', 'pyserial>=3.4,<4.0']

entry_points = \
{'console_scripts': ['lcbci = lcbci_lab._app:main']}

setup_kwargs = {
    'name': 'lcbci-lab',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'chanhakim',
    'author_email': 'chanhakim17@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
